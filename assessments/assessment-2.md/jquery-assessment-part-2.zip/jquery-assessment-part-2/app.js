$(function () {

$('.square').click(function () { 
  // This gets called on mouse click.
  // WRITE ME!
});

$('.square').hover(
  function () { 
    // This gets called when the cursor hovers over the shape.
    // WRITE ME!
  }, 
  function () {
    // This gets called when the cursor leaves the shape.
    // WRITE ME!
  });

});
